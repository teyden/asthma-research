## just some general tests for the moment

# library(rhdf5)
# tmp_file <- tempfile(fileext = ".h5")
# h5createFile(tmp_file)
# h5createGroup(tmp_file,"foo")
# h5createGroup(tmp_file,"baa")
# h5createGroup(tmp_file,"foo/foobaa")
# h5ls(tmp_file)
# 
# rhdf5:::h5lsTest("/home/msmith/projects/hdf5_testing/myhdf5file.h5")
# h5ls("/home/msmith/projects/hdf5_testing/myhdf5file.h5")
# 
# L <- .Call("_h5lsTest", H5Fopen("~/h5tutr_dset.h5")@ID, PACKAGE='rhdf5')
# 
# H5close()
# h5ls("/home/msmith/projects/hdf5_testing/myhdf5file.h5")
# 
# 
# 
# 
# 
# fid <- H5Fopen("/home/msmith/projects/hdf5_testing/myhdf5file.h5")
# gid <- H5Gopen(fid, "/foo")
# fid2 <- H5Fopen("/home/msmith/projects/hdf5_testing/myhdf5file.h5")
# oid <- H5Oopen(fid, "/foo")
# objs <- h5validObjects()
# 
# H5Fclose(fid)



