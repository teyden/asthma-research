library(testthat)
library(bayestestR)

test_check("bayestestR")
