## ----headers---------------------------------------------------------------
system.file(package="Rhdf5lib", "include")

## ----sessionInfo, echo=FALSE-----------------------------------------------
sessionInfo()

