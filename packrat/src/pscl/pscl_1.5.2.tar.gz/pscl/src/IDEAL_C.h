void IDEAL(int *n1, int *m1, int *d1, double *y1, int *maxiter1, int *thin1,
	   int *impute1, int *mda, double *xpriormeans1, 
	   double  *xpriorprec1, double *bpriormeans1, double *bpriorprec1, 
	   double *xstart1, double *bstart1, double *xoutput, double *boutput,
	   int *burnin1, int *usefile, int *bsave, char **filename1, int *verbose1,
	   int *limitvoters1, int *usevoter);
