void simpi(int *n, int *z);
