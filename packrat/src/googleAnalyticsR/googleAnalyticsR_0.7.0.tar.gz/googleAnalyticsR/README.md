# googleAnalyticsR
[![Travis-CI Build Status](https://travis-ci.org/MarkEdmondson1234/googleAnalyticsR.svg?branch=master)](https://travis-ci.org/MarkEdmondson1234/googleAnalyticsR)
![CRAN](http://www.r-pkg.org/badges/version/googleAnalyticsR)
[![codecov](https://codecov.io/gh/MarkEdmondson1234/googleAnalyticsR/branch/master/graph/badge.svg)](https://codecov.io/gh/MarkEdmondson1234/googleAnalyticsR)

![](https://raw.githubusercontent.com/MarkEdmondson1234/googleAnalyticsR/master/inst/hexlogo/hex.png)

Get more examples and tutorials at the [googleAnalyticsR website](http://code.markedmondson.me/googleAnalyticsR)

## Install

You also need `googleAuthR`

```r
install.packages("googleAuthR")
install.packages("googleAnalyticsR")
```

### Development version off github

```r
remotes::install_github("MarkEdmondson1234/googleAnalyticsR")
```
