# Jupyter resources

This contains resources helpful for running `googleAnalyticsR` on Jupyter notebooks, in particular those avaialable on the Google Cloud Platform's AI Hub where the package is installed by default.
