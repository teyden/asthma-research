This is an example of how to deploy to shinyapps.io using the newer `gar_shiny_*` functions. 

Note the additional option `options(googleAuthR.redirect = "https://mark.shinyapps.io/googleAnalyticsR_test_deployment/")` which should be set to the same URL as the redirect URL you need to configure in your Google Project for web application credentials.
