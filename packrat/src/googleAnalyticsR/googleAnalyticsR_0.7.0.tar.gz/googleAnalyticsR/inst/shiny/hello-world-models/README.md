This is an example of how to use `ga_model_*` functions to create Shiny apps.

The app authenticates using `gar_shiny_*` from `googleAuthR`, then loads a preexisting model that takes care of the UI and server side logic for fetching, modelling and plotting your Google Analytics data.
