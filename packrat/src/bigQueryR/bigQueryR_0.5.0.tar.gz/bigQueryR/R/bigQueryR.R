#' bigQueryR
#' 
#' Provides an interface with Google BigQuery
#' 
#' @seealso \url{https://cloud.google.com/bigquery/docs/reference/v2/?hl=en}
#' 
#' @docType package
#' @name bigQueryR
NULL


