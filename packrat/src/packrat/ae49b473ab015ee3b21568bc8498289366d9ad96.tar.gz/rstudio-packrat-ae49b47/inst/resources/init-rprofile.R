#### -- Packrat Autoloader (version 0.5.0-25) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
