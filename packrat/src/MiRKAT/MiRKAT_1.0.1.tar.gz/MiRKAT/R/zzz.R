.onLoad <- function(libname, pkg){
    library.dynam("MiRKAT", pkg, libname)
}
