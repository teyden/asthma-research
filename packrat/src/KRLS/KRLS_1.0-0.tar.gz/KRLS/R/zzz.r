.onAttach <-
function (libname, pkgname)
{
   # echo output to screen
   packageStartupMessage("## KRLS Package for Kernel-based Regularized Least Squares.\n")
   packageStartupMessage("## See Hainmueller and Hazlett (2014) for details.\n")
}

