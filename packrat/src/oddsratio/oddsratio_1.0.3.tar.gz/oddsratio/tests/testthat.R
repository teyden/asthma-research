library(testthat)
library(oddsratio)

test_check("oddsratio")
